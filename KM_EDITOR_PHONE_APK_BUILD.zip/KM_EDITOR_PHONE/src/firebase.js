import {initializeApp} from 'firebase/app';import {getAuth} from 'firebase/auth';import {getFirestore} from 'firebase/firestore';import {getStorage} from 'firebase/storage';
// Firebase Console থেকে config বসান
const config={apiKey:'YOUR_API_KEY',authDomain:'YOUR_PROJECT.firebaseapp.com',projectId:'YOUR_PROJECT_ID',storageBucket:'YOUR_PROJECT.appspot.com',messagingSenderId:'YOUR_SENDER_ID',appId:'YOUR_APP_ID'};
export const configured=!Object.values(config).some(x=>String(x).startsWith('YOUR_'));const app=initializeApp(config);export const auth=getAuth(app),db=getFirestore(app),storage=getStorage(app);
