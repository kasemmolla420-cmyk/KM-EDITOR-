KM EDITOR mobile APK build
1. Upload ALL files and folders in this directory to GitHub repo (including hidden .github).
2. GitHub repository -> Actions -> Build KM EDITOR APK -> Run workflow.
3. Workflow successful -> run page -> Artifacts -> KM-EDITOR-debug-apk download ZIP.
4. Extract artifact ZIP, install app-debug.apk.
Firebase: create Firebase project, enable Google Auth, Firestore, Storage, and replace src/firebase.js config. Set Firestore and Storage rules securely before production.
