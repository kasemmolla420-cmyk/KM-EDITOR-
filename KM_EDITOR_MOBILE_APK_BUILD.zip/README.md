# KM EDITOR — starter app

Mobile-friendly React + Vite app. Features:
- Home/latest feed, Photo feed, Video feed, Trending feed
- Photo/video upload with prompt/caption
- Google login (Firebase Authentication)
- Cloud uploads (Firebase Storage) and shared feed (Firestore)
- ChatGPT and Gemini prompt shortcuts

## Run
1. Install Node.js 20+.
2. Extract ZIP, open terminal in this folder:
   `npm install`
   `npm run dev`
3. For production build: `npm run build`

## Make uploads visible to all users (Firebase setup)
1. Create a project at https://console.firebase.google.com
2. Add a Web app and copy config values into `src/firebase.js`.
3. Enable Authentication → Google provider.
4. Create Firestore database and Storage bucket.
5. Deploy the included rules:
   `firebase deploy --only firestore:rules,storage`

## Important
This is a starter source project, not a published Play Store APK. Firebase credentials and project setup are needed for real login, uploads, and public shared content. "Trending" currently displays the upload feed (basic trending placeholder); add likes/views and ranking for real trending.

## Android phone-only APK build (GitHub Actions)
1. Upload all project files to GitHub (include `.github` and `capacitor.config.json`).
2. Repository → Actions → Build KM EDITOR APK → Run workflow.
3. After success, open workflow run → Artifacts → KM-EDITOR-debug-apk and download.
4. Extract artifact ZIP and install `app-debug.apk` on Android.
